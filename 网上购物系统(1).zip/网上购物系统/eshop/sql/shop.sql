/*
Navicat MySQL Data Transfer

Source Server         : 何青斌
Source Server Version : 80012
Source Host           : localhost:3306
Source Database       : shop

Target Server Type    : MYSQL
Target Server Version : 80012
File Encoding         : 65001

Date: 2018-10-29 22:43:04
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for address_info
-- ----------------------------
DROP TABLE IF EXISTS `address_info`;
CREATE TABLE `address_info` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL COMMENT '用户编号',
  `contact` varchar(20) NOT NULL COMMENT '联系人',
  `address` varchar(100) NOT NULL COMMENT '收货地址',
  `is_default` tinyint(1) NOT NULL COMMENT '是否为默认地址',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `modify_time` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of address_info
-- ----------------------------
INSERT INTO `address_info` VALUES ('1', '5', '李四', '长沙市', '1', '2018-10-22 22:16:43', '2018-10-26 15:19:15');
INSERT INTO `address_info` VALUES ('2', '5', '王五', '株洲市', '0', '2018-10-26 15:36:40', '2018-10-26 15:37:53');
INSERT INTO `address_info` VALUES ('3', '5', '李四', '长沙市', '1', '2018-10-26 15:45:59', '2018-10-26 20:33:15');
INSERT INTO `address_info` VALUES ('4', '3', '王五', '长沙市', '1', '2018-10-26 16:01:36', '2018-10-26 16:02:18');
INSERT INTO `address_info` VALUES ('7', '3', '李四', '长沙市', '0', '2018-10-26 16:02:07', null);

-- ----------------------------
-- Table structure for order_form
-- ----------------------------
DROP TABLE IF EXISTS `order_form`;
CREATE TABLE `order_form` (
  `order_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `total_price` int(10) NOT NULL,
  `receive_address` varchar(50) NOT NULL,
  `contact` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `order_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`order_id`),
  KEY `index_user_id` (`user_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of order_form
-- ----------------------------
INSERT INTO `order_form` VALUES ('1', '3', '2000', '长沙市', '黄文东', '2018-09-24 20:00:12');
INSERT INTO `order_form` VALUES ('2', '4', '20200', '株洲市', '张三', '2018-09-24 20:04:14');
INSERT INTO `order_form` VALUES ('3', '3', '2800', '长沙市', '张三', '2018-09-24 20:32:23');
INSERT INTO `order_form` VALUES ('4', '4', '18300', '株洲市', '李四', '2018-09-24 20:34:15');
INSERT INTO `order_form` VALUES ('5', '3', '20000', '湘潭市', '王五', '2018-09-25 20:40:11');
INSERT INTO `order_form` VALUES ('8', '3', '400', '长沙市', '王五', '2018-10-09 19:16:17');
INSERT INTO `order_form` VALUES ('11', '3', '23500', '长沙市', '王五', '2018-10-09 19:24:01');
INSERT INTO `order_form` VALUES ('24', '3', '7800', '长沙市', '王五', '2018-10-26 20:32:34');
INSERT INTO `order_form` VALUES ('25', '3', '333', '长沙市', '王五', '2018-10-29 22:38:25');
INSERT INTO `order_form` VALUES ('26', '3', '333', '长沙市', '王五', '2018-10-29 22:42:23');

-- ----------------------------
-- Table structure for order_product
-- ----------------------------
DROP TABLE IF EXISTS `order_product`;
CREATE TABLE `order_product` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `order_id` bigint(20) NOT NULL,
  `product_id` bigint(20) NOT NULL,
  `product_count` int(10) NOT NULL,
  `unit_price` int(20) NOT NULL,
  `total_price` int(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `index_order_id` (`order_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of order_product
-- ----------------------------
INSERT INTO `order_product` VALUES ('1', '1', '2', '5', '200', '1000');
INSERT INTO `order_product` VALUES ('2', '1', '1', '1', '1000', '1000');
INSERT INTO `order_product` VALUES ('3', '2', '3', '4', '4500', '18000');
INSERT INTO `order_product` VALUES ('4', '2', '5', '2', '1000', '2000');
INSERT INTO `order_product` VALUES ('5', '2', '4', '1', '200', '200');
INSERT INTO `order_product` VALUES ('6', '3', '2', '4', '200', '800');
INSERT INTO `order_product` VALUES ('7', '3', '5', '2', '1000', '2000');
INSERT INTO `order_product` VALUES ('8', '4', '1', '4', '1000', '4000');
INSERT INTO `order_product` VALUES ('9', '4', '2', '5', '200', '1000');
INSERT INTO `order_product` VALUES ('10', '4', '2', '4', '200', '800');
INSERT INTO `order_product` VALUES ('11', '4', '3', '3', '4500', '13500');
INSERT INTO `order_product` VALUES ('12', '5', '5', '2', '1000', '2000');
INSERT INTO `order_product` VALUES ('13', '5', '3', '4', '4500', '18000');
INSERT INTO `order_product` VALUES ('19', '8', '4', '1', '200', '200');
INSERT INTO `order_product` VALUES ('20', '8', '2', '1', '200', '200');
INSERT INTO `order_product` VALUES ('21', '11', '2', '4', '200', '800');
INSERT INTO `order_product` VALUES ('22', '11', '3', '5', '4500', '22500');
INSERT INTO `order_product` VALUES ('23', '24', '2', '4', '200', '800');
INSERT INTO `order_product` VALUES ('24', '24', '1', '7', '1000', '7000');
INSERT INTO `order_product` VALUES ('25', '25', '6', '1', '333', '333');
INSERT INTO `order_product` VALUES ('26', '26', '6', '1', '333', '333');

-- ----------------------------
-- Table structure for product_info
-- ----------------------------
DROP TABLE IF EXISTS `product_info`;
CREATE TABLE `product_info` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `enable` tinyint(1) DEFAULT '1' COMMENT '是否下线',
  `stock` int(20) NOT NULL COMMENT '库存',
  `specification` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `price` int(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of product_info
-- ----------------------------
INSERT INTO `product_info` VALUES ('1', '肥皂', '1', '10', '25g', '1000');
INSERT INTO `product_info` VALUES ('2', '火腿肠', '1', '20', '一根', '200');
INSERT INTO `product_info` VALUES ('3', '牛奶', '1', '20', '16瓶/一箱', '4500');
INSERT INTO `product_info` VALUES ('4', '苹果', '1', '30', '1个', '200');
INSERT INTO `product_info` VALUES ('5', '牙刷', '0', '40', '一只', '1000');
INSERT INTO `product_info` VALUES ('6', '垃圾袋', '1', '50', '100个', '500');
INSERT INTO `product_info` VALUES ('7', '面包', '0', '60', '100g', '500');
INSERT INTO `product_info` VALUES ('9', 'T恤', '1', '200', '175cm', '3000');

-- ----------------------------
-- Table structure for seckill_info
-- ----------------------------
DROP TABLE IF EXISTS `seckill_info`;
CREATE TABLE `seckill_info` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `product_id` bigint(20) NOT NULL COMMENT '商品编号',
  `product_name` varchar(40) NOT NULL COMMENT '商品名称',
  `seckill_count` int(20) NOT NULL COMMENT '秒杀商品数量',
  `seckill_price` int(20) NOT NULL COMMENT '秒杀商品的价格',
  `seckill_specification` varchar(40) NOT NULL COMMENT '规格',
  `seckill_start_time` datetime NOT NULL COMMENT '秒杀开始时间',
  `seckill_end_time` datetime NOT NULL COMMENT '秒杀结束时间',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modify_time` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of seckill_info
-- ----------------------------
INSERT INTO `seckill_info` VALUES ('1', '1', '肥皂', '10', '100', '25g', '2018-10-28 20:50:22', '2018-10-28 20:50:49', '2018-10-27 17:48:56', '2018-10-28 20:49:18');
INSERT INTO `seckill_info` VALUES ('2', '9', 'T恤', '11', '1111', '175cm', '2018-10-29 12:33:00', '2018-10-29 12:34:00', '2018-10-29 12:24:17', null);
INSERT INTO `seckill_info` VALUES ('3', '2', '火腿肠', '11', '1111', '一根', '2018-10-29 13:17:00', '2018-10-29 13:18:00', '2018-10-29 13:15:34', null);
INSERT INTO `seckill_info` VALUES ('5', '3', '牛奶', '2', '222', '16瓶/一箱', '2018-10-29 20:50:00', '2018-10-29 20:51:00', '2018-10-29 20:48:28', null);
INSERT INTO `seckill_info` VALUES ('6', '6', '垃圾袋', '1', '333', '100个', '2018-10-29 22:42:22', '2018-10-29 22:43:00', '2018-10-29 20:59:53', '2018-10-29 22:41:11');
INSERT INTO `seckill_info` VALUES ('7', '1', '肥皂', '4', '444', '25g', '2018-10-29 21:41:30', '2018-10-29 21:42:44', '2018-10-29 21:00:29', '2018-10-29 21:40:59');

-- ----------------------------
-- Table structure for user_info
-- ----------------------------
DROP TABLE IF EXISTS `user_info`;
CREATE TABLE `user_info` (
  `user_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(20) DEFAULT NULL COMMENT '用户名',
  `password` varchar(40) DEFAULT NULL COMMENT '密码',
  `role_id` int(11) DEFAULT NULL COMMENT '角色',
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `modify_time` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user_info
-- ----------------------------
INSERT INTO `user_info` VALUES ('1', 'admin', '37dc628b62fbe54b4ba55dcee93be0d2', '1', '2018-09-23 19:39:25', '2018-10-09 17:35:00');
INSERT INTO `user_info` VALUES ('3', 'user02', '0302ced804ffefd7763993765fa59a8e', '2', '2018-09-23 19:39:25', null);
INSERT INTO `user_info` VALUES ('5', 'user04', 'c13fc82b82efcbef92370e1860242325', '2', '2018-10-09 17:36:50', '2018-10-09 17:36:58');
INSERT INTO `user_info` VALUES ('33', 'null', '928e29b52397a883e05bd36115fe3422', '2', '2018-10-12 21:53:53', null);
SET FOREIGN_KEY_CHECKS=1;
