package com.study.shop.util;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class ConsoleUtil {

	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	
	public static String readLine(){
		String line = null;
		try {
			line =  br.readLine();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return line;
	}
	
	public static void clear(){
		try {
			Robot r = new Robot();
			r.mousePress(InputEvent.BUTTON3_MASK); // 按下鼠标右键
			r.mouseRelease(InputEvent.BUTTON3_MASK); // 释放鼠标右键
			
			r.keyPress(KeyEvent.VK_CONTROL); // 按下Ctrl键
			r.keyPress(KeyEvent.VK_R); // 按下R键
			r.keyRelease(KeyEvent.VK_R); // 释放R键
			r.keyRelease(KeyEvent.VK_CONTROL); // 释放Ctrl键
			r.delay(100);
			
		} catch (Exception ex) {
		}
	}
}
