package com.study.shop.mvc;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.study.shop.domain.AddressInfo;
import com.study.shop.service.AddressService;

@Controller
@RequestMapping("/address")
public class AddressController extends BaseController{
    
    @Autowired
    private AddressService addressService;
    
    /**
     * 跳转到收货地址界面
     * @return
     */
    @RequestMapping("/view")
    public String address(HttpServletRequest reqeust, Long userId){
        reqeust.setAttribute("addressInfoList", addressService.getAddressList(this.getUserId().longValue()));
        return "address";
    }
    
    /**
     * 添加收货地址
     * @param addressInfo
     * @return
     */
    @ResponseBody
    @RequestMapping("/addAddress")
    public String addAddress(AddressInfo addressInfo, HttpServletRequest request) {
        AddressInfo defaultAddress = addressService.getDefaultAddress(this.getUserId().longValue());
        if (defaultAddress == null) {
            addressInfo.setIsDefault(true);
        } else {
            addressInfo.setIsDefault(false);
        }
        
        addressInfo.setUserId(this.getUserId().longValue());
        addressService.insertAddress(addressInfo);
        request.setAttribute("addressInfoList", addressService.getAddressList(this.getUserId().longValue()));
        return this.responseResult("添加成功！");
    }
    
    /**
     *  修改收货地址(--------------------未实现)
     * @param addressInfo
     * @return
     */
    @RequestMapping("/modifyAddress")
    public void modifyAddress(Long id, Long userId, HttpServletRequest request, HttpServletResponse response) {
        addressService.updateDefaultAddress(id, userId);
        request.setAttribute("addressInfoList", addressService.getAddressList(this.getUserId().longValue()));
        this.responseSendMsg(response, CODE_SUCCESS);
    }
    
    /**
     *  删除收货地址
     * @param removeAddress
     */
    @RequestMapping("/removeAddress")
    public void removeAddress(Long id, HttpServletRequest request, HttpServletResponse response){
        addressService.deleteAddressById(id, this.getUserId().longValue());
        request.setAttribute("addressInfoList", addressService.getAddressList(this.getUserId().longValue()));
        this.responseSendMsg(response, CODE_SUCCESS);
    }
}
