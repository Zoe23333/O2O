package com.study.shop.service.impl;

import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.study.shop.domain.AddressInfo;
import com.study.shop.domain.Order;
import com.study.shop.domain.OrderProduct;
import com.study.shop.domain.SeckillInfo;
import com.study.shop.domain.SeckillInfoExample;
import com.study.shop.mapper.OrderMapper;
import com.study.shop.mapper.OrderProductMapper;
import com.study.shop.mapper.SeckillInfoMapper;
import com.study.shop.service.SeckillService;
import com.study.shop.util.ReturnUtil;

@Service
public class SeckillServiceImpl implements SeckillService {
    @Autowired
    private SeckillInfoMapper seckillInfoMapper;
    @Autowired
    private OrderProductMapper orderProductMapper;
    @Autowired
    private OrderMapper orderMapper;

    @Override
    public Long insert(SeckillInfo seckill) {
        seckillInfoMapper.insertSelective(seckill);
        return seckill.getId();
    }

    @Override
    public void update(SeckillInfo seckill) {
        seckillInfoMapper.updateByPrimaryKeySelective(seckill);
    }

    @Override
    public SeckillInfo getSeckillInfoById(Long id) {
        return seckillInfoMapper.selectByPrimaryKey(id);
    }

    @Override
    public List<SeckillInfo> getSeckillInfoList() {
        SeckillInfoExample example = new SeckillInfoExample();
        List<SeckillInfo> list = seckillInfoMapper.selectByExample(example);
      
        Iterator<SeckillInfo> iterator = list.iterator();
        while (iterator.hasNext()) {
            SeckillInfo seckillInfo = iterator.next();
            boolean noSale = (seckillInfo.getSeckillCount() == 0) || (seckillInfo.getSeckillEndTime().getTime() < new Date().getTime());
            if (noSale) {
                iterator.remove();
            }
        }
        return new ReturnUtil<SeckillInfo>().returnList(list);
    }

    @Override
    public void insertSeckillOrder(SeckillInfo seckillInfo, AddressInfo addressInfo) {
        Order order = new Order();
            
        order.setUserId(addressInfo.getUserId());
        order.setReceiveAddress(addressInfo.getAddress());
        order.setContact(addressInfo.getContact());
        order.setTotalPrice(seckillInfo.getSeckillPrice());
        
        orderMapper.insertSelective(order);
        
        OrderProduct orderProduct = new OrderProduct();
        orderProduct.setOrderId(order.getOrderId());
        orderProduct.setProductCount(1);
        orderProduct.setProductId(seckillInfo.getProductId());
        orderProduct.setUnitPrice(seckillInfo.getSeckillPrice());
        orderProduct.setTotalPrice(seckillInfo.getSeckillPrice());
        
        orderProductMapper.insertSelective(orderProduct);
    }

    @Override
    public boolean updateSeckillInfoWhenSeckill(Long id) {
        SeckillInfo seckillInfo = seckillInfoMapper.selectSeckillAndLockById(id);
        Integer count = seckillInfo.getSeckillCount();
        if (count > 0) {
            seckillInfo.setSeckillCount(count - 1);
            seckillInfoMapper.updateByPrimaryKeySelective(seckillInfo);
            return true;
        } else {
            return false;
        }
    }

}
