package com.study.shop.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.study.shop.domain.Order;
import com.study.shop.domain.OrderExample;
import com.study.shop.domain.OrderProduct;
import com.study.shop.domain.OrderProductExample;
import com.study.shop.domain.ProductExample;
import com.study.shop.mapper.OrderMapper;
import com.study.shop.mapper.OrderProductMapper;
import com.study.shop.mapper.ProductMapper;
import com.study.shop.service.OrderService;
import com.study.shop.util.ReturnUtil;
@Service
public class OrderServiceImpl implements OrderService {
	@Autowired
	private OrderMapper orderMapper;
	@Autowired
	private OrderProductMapper orderProductMapper;
	@Autowired
	private ProductMapper productMapper;
	
	@Override
	public List<Order> getAllOrderForm() {
		 //todo:太奇怪 查询所有数据 应该是不传参就行了(以解决)
	    List<Order> list = orderMapper.selectByExample(new OrderExample());
	    return new ReturnUtil<Order>().returnList(list);
	}

	@Override
	public List<Order> myOrderForm(long userId) {
		//todo:传入的就是userId, 何必多此一举?(已修改)
	    OrderExample example = new OrderExample();
	    example.or().andUserIdEqualTo(userId);
	    List<Order> list = orderMapper.selectByExample(example);
	    
	    return new ReturnUtil<Order>().returnList(list);
	}

	@Override
    public void insertOrder(Order order) {
        //todo:设计错误! 如果有多用户并发访问时, 查的max(id)不一定是本人创建。正确做法应该是在insert时返回获取
	    //(以解决---通过useGeneratedKeys="true"(返回新增的主键) keyProperty="orderId"(主键对应的属性))
	    orderMapper.insertSelective(order);
        for (OrderProduct temp : order.getOrderProductList()) {
            temp.setOrderId(order.getOrderId());
        }
        
        orderProductMapper.insertOrderProductList(order.getOrderProductList());
    }

	@Override
	public List<OrderProduct> insertProductInCart(List<OrderProduct> orderProductList,long productId,int productCount) {
		// 如果是相同商品直接添加在购物车中的商品中
	    for (OrderProduct orderProduct : orderProductList) {
			if (orderProduct.getProductId() == productId) {
			    orderProduct.setProductCount(orderProduct.getProductCount() + productCount);
			    orderProduct.setTotalPrice(orderProduct.getTotalPrice() + productCount *orderProduct.getUnitPrice() );
				return orderProductList;
			}
		}
		
		OrderProduct orderProduct = new OrderProduct();
		int unitPrice = productMapper.selectByPrimaryKey(productId).getPrice();
		
		orderProduct.setProductId(productId);
		orderProduct.setProductCount(productCount);
		orderProduct.setUnitPrice(unitPrice);
		orderProduct.setTotalPrice(unitPrice*productCount);
		
		orderProductList.add(orderProduct);
		return orderProductList;
	}

	@Override
	public List<OrderProduct> delectProductInCart(List<OrderProduct> orderProductList, long productId) {
		for (OrderProduct orderProduct : orderProductList) {
			if(orderProduct.getProductId()==productId){
				orderProductList.remove(orderProduct);
				break;
			}
		}
		return new ReturnUtil<OrderProduct>().returnList(orderProductList);
	}

	@Override
	public List<OrderProduct> selectOrderProductByOrderId(long orderId) {
	    OrderProductExample example = new OrderProductExample();
	    example.or().andOrderIdEqualTo(orderId);
	    List<OrderProduct> list = orderProductMapper.selectByExample(example);
	   
	    return new ReturnUtil<OrderProduct>().returnList(list);
	}

}
