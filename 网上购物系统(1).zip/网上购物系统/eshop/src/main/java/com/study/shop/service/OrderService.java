package com.study.shop.service;

import java.util.List;

import com.study.shop.domain.Order;
import com.study.shop.domain.OrderProduct;

public interface OrderService {
    
	/**
	 * 返回所有订单信息
	 * 
	 * @return
	 */
	List<Order> getAllOrderForm();
	
	/**
	 * 返回当前用户的所有订单
	 * 
	 * @param userId
	 * @return
	 */
	List<Order> myOrderForm(long userId);
	
	/**
	 * 添加订单
	 * 
	 * @param order
	 */
	void insertOrder(Order order);
	
	/**
	 * 在购物车内添加订单
	 * 
	 * @param orderProductList 购物车
	 * @param productId
	 * @param productCount
	 * @return 添加商品后的购物车
	 */
	List<OrderProduct> insertProductInCart(List<OrderProduct> orderProductList,long productId,int productCount);

	/**
	 * 删除购物车中的商品
	 * 
	 * @param orderProductList 购物车
	 * @param productId
	 * @return  删除商品后的购物车
	 */
	List<OrderProduct> delectProductInCart(List<OrderProduct> orderProductList,long productId);
	
	/**
	 * 通过订单id获取订单中的商品
	 * 
	 * @param orderId
	 * @return
	 */
	List<OrderProduct> selectOrderProductByOrderId(long orderId);
}
