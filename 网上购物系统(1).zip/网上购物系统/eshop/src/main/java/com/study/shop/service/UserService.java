package com.study.shop.service;

import java.util.List;

import com.study.shop.domain.UserInfo;

public interface UserService {

    /**
     * 检查登录
     * 
     * @param username
     * @param password
     * @return
     */
    boolean checkLogin(String username, String password);

    /**
     * 通过用户id返回用户信息
     * 
     * @param userId
     * @return
     */
    UserInfo getById(long userId);

    /**
     * 通过用户名返回用户信息
     * 
     * @param username
     * @return
     */
    UserInfo getByUsername(String username);

    /**
     * 添加用户
     * 
     * @param userInfo
     */
    void insert(UserInfo userInfo);

    /**
     * 更新用户信息
     * 
     * @param userInfo
     */
    void update(UserInfo userInfo);

    /**
     * 通过用户id删除用户
     * 
     * @param userId
     */
    void deleteById(long userId);

    /**
     * 返回所有用户信息
     * 
     * @return
     */
    List<UserInfo> getAllUserInfo();

    /**
     * 检查密码是否正确
     * 
     * @param userInfo
     * @param password
     * @return
     */
    boolean checkPassword(UserInfo userInfo, String password);

}
