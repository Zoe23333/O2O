package com.study.shop.mvc;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.study.shop.domain.UserInfo;
import com.study.shop.service.UserService;

/**
 * @author 14380
 *
 */
@Controller
@RequestMapping("/user")
public class UserController extends BaseController{
	
	@Autowired
	private UserService userService;
	
	/**
    @ResponseBody
    @RequestMapping(value = "/login", method = {RequestMethod.POST, RequestMethod.GET})
	public ResponseResult<String> login(String username, String password){
		boolean loginOk = userService.checkLogin(username, password);
		if(loginOk){
			return ResponseResult.inst("/main/dispatch");
		}else{
			return ResponseResult.inst(ResponseResult.CODE_ERROR, "用户名或密码错误,请重新登录", "");
		}
    }
    */
	
	@RequestMapping(value = "/login", method = {RequestMethod.POST, RequestMethod.GET})
		public String login(String username, String password, HttpServletResponse response){
			if(username==null){
				return "redirect:/login.jsp";
			}
			boolean loginOk = userService.checkLogin(username, password);
			if(loginOk){
			    UserInfo userInfo = userService.getByUsername(username);
			    this.setUserId(userInfo.getUserId().intValue());
				return "redirect:/main/dispatch";
			}else{
			    this.responseHTML(response, this.responseResult("用户名或者密码错误!"));
				return null;
//				return "redirect:/login.jsp";
			}
	    }
    /**
     * 用户管理
     * @param req
     * @return
     */
    @RequestMapping("/userInfo")
    public String userInfo(HttpServletRequest request){
		request.setAttribute("userList", userService.getAllUserInfo());
    	return "userInfo";
    }
    
    /**
     * 修改密码
     * @param oldPassword
     * @param newPassword
     * @param request
     * @return
     */
    @ResponseBody
    @RequestMapping("/updatePassword")
    public String updatePassword(String oldPassword,String newPassword,HttpServletRequest request,HttpServletResponse response){
		UserInfo userInfo = userService.getById(this.getUserId());
		if(userService.checkPassword(userInfo, oldPassword)){
			userInfo.setPassword(newPassword.substring(0, newPassword.indexOf(",")));
			userService.update(userInfo);
			return this.responseResult("密码修改成功!");
		}else{
			return this.responseResult("旧密码错误!");
		}
    }
    
    /**
     * 退出登录
     * @return
     */
    @RequestMapping("/exit")
    public String exit(HttpSession session){
    	session.invalidate();
    	return "redirect:/login.jsp";
    }
    
    /**
     * 添加用户
     * @param userInfo
     * @return
     */
    @ResponseBody
    @RequestMapping("/addUser")
    public String addUser(UserInfo userInfo,HttpSession session){
        UserInfo info = this.userService.getByUsername(userInfo.getUserName());
        if (info == null) {
            userService.insert(userInfo);
            session.setAttribute("userList", userService.getAllUserInfo());
            return this.responseResult("添加用户成功!");
        } else {
            return this.responseErrorResult("用户已存在");
        }
    }
    
    /**
     * 删除用户
     * @param userId
     */
    @ResponseBody
    @RequestMapping("/delectUser")
    public String delectUser(long userId,HttpServletRequest request){
    	userService.deleteById(userId);
    	request.setAttribute("userList", userService.getAllUserInfo());
    	return null;
    }
}
