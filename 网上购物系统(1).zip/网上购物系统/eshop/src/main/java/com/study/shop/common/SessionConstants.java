package com.study.shop.common;

/**
 * 会话常量
 * @author Jindaodaxia
 *
 */
public class SessionConstants {
	public static final String KEY_USER = "user";
	
}
