package com.study.shop.service;

import java.util.List;

import com.study.shop.domain.AddressInfo;

public interface AddressService {
    
    /**
     * 添加地址
     * @param addressInfo
     */
    void insertAddress(AddressInfo addressInfo);

    /**
     * 更新地址
     * @param addressInfo
     */
    void updateAddress(AddressInfo addressInfo);

    /**
     * 通过id删除地址 (需要判断是否还有默认地址，如果没有则将第一条地址改为默认地址)
     * @param id
     * @param userId 
     */
    void deleteAddressById(Long id, Long userId);

    /**
     * 返回用户的所有地址
     * @param userId
     * @return
     */
    List<AddressInfo> getAddressList(Long userId); //todo: getAddressList
    

    /**
     * 返回用户的默认地址
     * 
     * @param userId
     * @return
     */
    AddressInfo getDefaultAddress(Long userId); //todo: getDefaulAddress
    
    /**
     * 通过id返回用户信息
     * 
     * @param id
     * @return
     */
    AddressInfo getAddressById(Long id);
    
    /**
     * 更新默认地址
     * (先通过用户id将原默认地址修改为false，再将参数id的地址改为默认)
     * 
     * @param id
     * @param userId
     */
    void updateDefaultAddress(Long id, Long userId);
}
