package com.study.shop.mvc;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.study.shop.domain.Order;
import com.study.shop.domain.OrderProduct;
import com.study.shop.service.OrderService;
import com.study.shop.service.ProductService;

@Controller
@RequestMapping("/order")
public class OrderController extends BaseController {
	@Autowired
	private ProductService productService;
	@Autowired
	private OrderService orderService;

	/**
	 * 订单列表
	 * @param request
	 * @return
	 */
	@RequestMapping("/list")
	public String list(HttpServletRequest request) {
		request.setAttribute("orderList", orderService.getAllOrderForm());
		return "orderList";
	}

	/**
	 * 我的订单
	 * @param request
	 * @return
	 */
	@RequestMapping("/myOrder")
	public String myOrderList(HttpServletRequest request) {
		request.setAttribute("orderList", orderService.myOrderForm(this.getUserId()));
		return "orderList";
	}

	/**
	 * 下单
	 * @param order
	 * @param request
	 */
	@ResponseBody
	@RequestMapping("/order")
	public String order(Order order, HttpServletRequest request,HttpServletResponse response) {
	    if (request.getSession().getAttribute("cart") == null) {
	        return this.responseResult("没有购买的商品!");
	    }
		order.setUserId(this.getUserId().longValue());
		order.setOrderProductList((List<OrderProduct>) request.getSession().getAttribute("cart"));
		order.setTotalPrice((int) request.getSession().getAttribute("totalPrice"));
	
		orderService.insertOrder(order);
		request.getSession().setAttribute("totalPrice", null);
		request.getSession().setAttribute("cart", null);
		return this.responseResult("下单成功!");
	}

	/**
	 * 订单中的商品信息
	 * @param userId
	 * @param session
	 * @return
	 */
	@RequestMapping("/orderProduct")
	public String orderProduct(Long orderId,HttpServletRequest request) {
		request.setAttribute("orderProductList", orderService.selectOrderProductByOrderId(orderId));
		return "orderProduct";
	}

	/**
	 * 添加购物车
	 * @param session
	 * @param productId
	 * @param productCount
	 */
	@RequestMapping("/addProductInCart")
	public void addProductInCart(HttpSession session, long productId, int productCount, HttpServletResponse response) {
		if (session.getAttribute("cart") == null) {
			session.setAttribute("cart",
					orderService.insertProductInCart(new ArrayList<OrderProduct>(), productId, productCount));
			session.setAttribute("totalPrice",productService.getProductPrice(productId)*productCount);
		} else {
			session.setAttribute("cart", orderService.insertProductInCart((List<OrderProduct>) session.getAttribute("cart"), productId, productCount));
			int price = productService.getProductPrice(productId)*productCount;
			session.setAttribute("totalPrice", (Integer)session.getAttribute("totalPrice")+price);
		}
		 this.responseTXT(response, "添加成功!");
	}
	
	/**
	 * 删除购物车的商品
	 * @param session
	 * @param delectId
	 */
	@RequestMapping("/delectProductInCart")
	public void delectProductInCart(HttpSession session,long delectId,int count, HttpServletResponse response){
		List<OrderProduct> cart = orderService.delectProductInCart((List<OrderProduct>) session.getAttribute("cart"), delectId);
		session.setAttribute("cart", cart);
		int price = productService.getProductPrice(delectId)*count;
		session.setAttribute("totalPrice", ((Integer)session.getAttribute("totalPrice"))-price);
		this.responseHTML(response, CODE_SUCCESS);;
	}
}
