package com.study.shop.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.study.shop.domain.AddressInfo;
import com.study.shop.domain.AddressInfoExample;
import com.study.shop.mapper.AddressInfoMapper;
import com.study.shop.service.AddressService;
import com.study.shop.util.ReturnUtil;

@Service
public class AddressServiceImpl implements AddressService{

    @Autowired
    private AddressInfoMapper addressInfoMapper;
    
    @Override
    public void insertAddress(AddressInfo addressInfo) {
        addressInfoMapper.insertSelective(addressInfo);
    }

    @Override
    public void updateAddress(AddressInfo addressInfo) {
        addressInfoMapper.updateByPrimaryKey(addressInfo);
    }

    @Override
    public void deleteAddressById(Long id, Long userId) {
        addressInfoMapper.deleteByPrimaryKey(id);
        if (this.getDefaultAddress(userId) == null) {
            AddressInfoExample example = new AddressInfoExample();
            example.or().andUserIdEqualTo(userId);
            List<AddressInfo> list = addressInfoMapper.selectByExample(example);
            
            if (list.size() > 0) {
                list.get(0).setIsDefault(true);
                addressInfoMapper.updateByPrimaryKeySelective(list.get(0));
            }
        }
    }

    @Override
    public List<AddressInfo> getAddressList(Long userId) {
        AddressInfoExample example = new AddressInfoExample();
        example.or().andUserIdEqualTo(userId);
        List<AddressInfo> list = addressInfoMapper.selectByExample(example);
        
        return new ReturnUtil<AddressInfo>().returnList(list);
    }

    @Override
    public AddressInfo getDefaultAddress(Long userId) {
        AddressInfoExample example = new AddressInfoExample();
        example.or().andUserIdEqualTo(userId).andIsDefaultEqualTo(true);
        List<AddressInfo> list = addressInfoMapper.selectByExample(example);
        
        return new ReturnUtil<AddressInfo>().returnObject(list);
    }

    @Override
    public AddressInfo getAddressById(Long id) {
        return addressInfoMapper.selectByPrimaryKey(id);
    }

    @Override
    public void updateDefaultAddress(Long id, Long userId) {
        AddressInfo defaultAddress = this.getDefaultAddress(userId);
        defaultAddress.setIsDefault(false);
        this.updateAddress(defaultAddress);
        
        AddressInfo addressInfo = getAddressById(id);
        addressInfo.setIsDefault(true);
        this.updateAddress(addressInfo);
    }
}
