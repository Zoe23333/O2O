package com.study.shop.mvc;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.study.shop.domain.AddressInfo;
import com.study.shop.domain.Product;
import com.study.shop.domain.SeckillInfo;
import com.study.shop.service.AddressService;
import com.study.shop.service.ProductService;
import com.study.shop.service.SeckillService;

@Controller
@RequestMapping("/product")
public class ProductController extends BaseController{
    @Autowired
    private ProductService productService;
    @Autowired
    private SeckillService seckillService;
    @Autowired
    private AddressService addressService;
    
    /**
     * 下线商品
     * @param downlineId
     */
    @RequestMapping("/downline")
    public void downline(long downlineId,HttpServletResponse response) {
        int count = productService.updateToDisableProduct(downlineId);
        if (count == 1) {
            this.responseHTML(response, CODE_SUCCESS);
        } else {
            this.responseHTML(response, CODE_ERROR);
        }
    }
    
    /**
     * 添加商品
     * @param request
     * @param response
     * @param product
     * @return
     * @throws IOException
     */
    @ResponseBody
    @RequestMapping("/addProduct")
    public String addProduct(HttpServletRequest request,HttpServletResponse response, Product product) throws IOException {
        product.setPrice(product.getPrice()*100);
        int count = productService.insertProduct(product);
        if (count == 1) {
            return this.responseResult("添加商品成功!");
        } else {
            return this.responseResult("添加商品失败!");
        }
    }
    
    /**
     * 商品管理界面
     *
     * @param session
     * @return
     */
    @RequestMapping("/product")
    public String product(HttpServletRequest request) {
        request.setAttribute("productList", productService.getProductList());
        return "product";
    }
    
    /**
     * 添加秒杀商品
     * 
     * @param seckill
     */
    @RequestMapping("/addSeckill")
    public void addSeckill(SeckillInfo seckill, String startTime,
            String endTime, HttpServletRequest request, HttpServletResponse response) {
        seckill.setSeckillStartTime(new Date(Long.parseLong(startTime)));
        seckill.setSeckillEndTime(new Date(Long.parseLong(endTime)));
        
        Product product = productService.getProductById(seckill.getProductId());
        seckill.setSeckillPrice(seckill.getSeckillPrice()*100);
        seckill.setProductName(product.getName());
        seckill.setSeckillSpecification(product.getSpecification());
        Long id = seckillService.insert(seckill);
        
        ServletContext context = request.getServletContext();
        context.setAttribute("count" + id, seckill.getSeckillCount());
        this.responseTXT(response, "添加秒杀商品成功!");;
    }
    
    /**
     * 秒杀信息界面
     * 
     * @param session
     * @return
     */
    @RequestMapping("/seckillView")
    public String seckillView(HttpServletRequest request) {
        List<SeckillInfo> seckillList = seckillService.getSeckillInfoList();
        request.setAttribute("seckillList", seckillList);
        return "seckillView";
    }
    
    /**
     * 秒杀商品
     * 
     * @param request
     * @param id
     * @return
     */
    @RequestMapping("/seckillProduct")
    public void seckillProduct(HttpServletRequest request, Long id, HttpServletResponse response){
        boolean success = seckillService.updateSeckillInfoWhenSeckill(id);
        if (success) {
            SeckillInfo seckillInfo = seckillService.getSeckillInfoById(id);
            AddressInfo addressInfo = addressService.getDefaultAddress(this.getUserId().longValue());
            seckillService.insertSeckillOrder(seckillInfo, addressInfo);
            this.responseHTML(response, "秒杀成功!");
        } else {
            this.responseHTML(response, "没抢到!");
        }
    }
    
    /**
     * 判断是否售完
     * 
     * @param request
     * @param id
     * @return
     *//*
    public boolean isSellOut(HttpServletRequest request, Long id) {
        ServletContext context = request.getServletContext();
        synchronized (ProductController.class) {
            long count = 0;
            Object object = context.getAttribute("count" + id) ;
            if (object != null) {
                count = (long) object;
            } else {
                return true;
            }
            if (count > 0) {
                LongAdder longAdder = new LongAdder();
                longAdder.add(count);
                longAdder.decrement();
                context.setAttribute("count" + id, longAdder.sum());
                if (longAdder.sum() == 0) {
                    context.removeAttribute("count" + id);
                }
                return false;
            } else {
                return true;
            }
        }
    }*/
}
