package com.study.shop.mvc;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.study.shop.domain.AddressInfo;
import com.study.shop.domain.UserInfo;
import com.study.shop.service.AddressService;
import com.study.shop.service.ProductService;
import com.study.shop.service.UserService;

@Controller
@RequestMapping("/main")
public class MainController extends BaseController {
    @Autowired
    private ProductService productService;
    @Autowired
    private UserService userService;
    @Autowired
    private AddressService addressService;

    /**
     * 分派处理用户输入
     * 
     * @param input
     * @throws IOException
     */
    @RequestMapping("/dispatch")
    public String dispatch(HttpServletRequest request) {
        UserInfo userInfo = userService.getById(this.getUserId());
        if (userInfo.getRoleId() == 1) {
            return "manager";
        } else {
            request.setAttribute("productList", productService.getProductList());
            AddressInfo address = addressService.getDefaultAddress(this.getUserId().longValue());
            if (address != null) {
                request.getSession().setAttribute("defaultAddress", address);
            }
            return "userView";
        }
    }
}
