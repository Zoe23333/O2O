package com.study.shop.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.study.shop.domain.UserInfo;
import com.study.shop.domain.UserInfoExample;
import com.study.shop.mapper.UserInfoMapper;
import com.study.shop.service.UserService;
import com.study.shop.util.MD5;
import com.study.shop.util.ReturnUtil;

@Service
public class UserServiceImpl implements UserService {
	@Autowired
	private UserInfoMapper userInfoMapper;
	
	private static final String SALT = "z25gc36O70wnV4S6";
	/*
	 * 密码单向加密
	 */
	private String getEncryptPassword(String password){
		return MD5.getMessageDigest(SALT + password);
	}
	
	@Override
	public boolean checkLogin(String username, String password) {
		UserInfo userInfo = getByUsername(username);
		boolean isLogin = (userInfo != null) && (userInfo.getPassword().equals(getEncryptPassword(password)));
		if(isLogin){
			return true;
		}
		return false;
	}

	@Override
	public UserInfo getById(long userId) {
		return userInfoMapper.selectByPrimaryKey(userId);
	}

	@Override
	public UserInfo getByUsername(String username) {
		UserInfoExample example = new UserInfoExample();
		example.or().andUserNameEqualTo(username);
		List<UserInfo> list = userInfoMapper.selectByExample(example);
		
		return new ReturnUtil<UserInfo>().returnObject(list);
	}

	@Override
	public void insert(UserInfo userInfo) {
		//密码加密存储, 防止破解
		String encryptPassword = getEncryptPassword(userInfo.getPassword());
		userInfo.setPassword(encryptPassword);
		userInfoMapper.insertSelective(userInfo);
	}

	@Override
	public void update(UserInfo userInfo) {
		String encryptPassword = getEncryptPassword(userInfo.getPassword());
		userInfo.setPassword(encryptPassword);
		userInfoMapper.updateByPrimaryKey(userInfo);
	}

	@Override
	public void deleteById(long userId) {
		userInfoMapper.deleteByPrimaryKey(userId);
	}

	@Override
	public List<UserInfo> getAllUserInfo() {
	    return userInfoMapper.selectByExample(new UserInfoExample());
	}

	@Override
	public boolean checkPassword(UserInfo userInfo,String password) {
	    boolean correct = userInfo.getPassword().equals(getEncryptPassword(password));
		if(correct){
			return true;
		}
		return false;
	}

}
