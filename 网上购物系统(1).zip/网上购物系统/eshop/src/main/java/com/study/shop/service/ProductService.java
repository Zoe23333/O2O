package com.study.shop.service;

import java.util.List;

import com.study.shop.domain.Product;

public interface ProductService {
    /**
     * 返回商品列表
     * 
     * @return
     */
    List<Product> getProductList();

    /**
     * 添加商品
     *
     * @param product
     * @return
     */
    int insertProduct(Product product);

    /**
     * 下线商品
     * 
     * @param productId
     * @return
     */
    int updateToDisableProduct(long productId);

    /**
     * 返回商品价格
     * 
     * @param productId
     * @return
     */
    int getProductPrice(long productId);

    /**
     * 通过id返回商品信息
     * 
     * @param id
     * @return
     */
    Product getProductById(Long id);
}
