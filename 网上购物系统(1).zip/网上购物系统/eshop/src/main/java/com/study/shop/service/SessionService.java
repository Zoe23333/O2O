package com.study.shop.service;

import java.util.HashMap;
import java.util.Map;

/**
 * 会话服务(模拟web会话 只支持单用户)
 * @author Jindaodaxia
 *
 */

public class SessionService {
	private static Map<String,Object> sessionMap = new HashMap<String,Object>();
	
	/**
	 * 设置session
	 * @param key
	 * @param value
	 */
	public static void setSession(String key, Object value){
		sessionMap.put(key, value);
	}
	
	/**
	 * 获取session
	 * @param key
	 * @return
	 */
	public static Object getSession(String key){
		return sessionMap.get(key);
	}
	
	/**
	 * 清空session
	 */
	public static void clear(){
		sessionMap.clear();
	}
}
