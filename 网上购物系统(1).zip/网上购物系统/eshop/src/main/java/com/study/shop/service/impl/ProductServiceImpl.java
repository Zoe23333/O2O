package com.study.shop.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.study.shop.domain.Product;
import com.study.shop.domain.ProductExample;
import com.study.shop.mapper.ProductMapper;
import com.study.shop.service.ProductService;
import com.study.shop.util.ReturnUtil;
@Service
public class ProductServiceImpl implements ProductService {
	@Autowired
	private ProductMapper productMapper;
	
	@Override
	public List<Product> getProductList() {
		//todo:功能权限应该在控制器做, service只对接口负责(以修改--因为有个isenable字段，所以直接返回了所有商品)
	    List<Product> list = productMapper.selectByExample(new ProductExample());
	    return new ReturnUtil<Product>().returnList(list);
	}

	@Override
	public int insertProduct(Product product) {
		return productMapper.insertSelective(product);
	}
	
	@Override
	public int updateToDisableProduct(long productId) {
		//todo:下线商品，应该是商品里面有个enable字段，1正常 0禁用  下线之后,不对用户展示(已修改)
	    Product product = productMapper.selectByPrimaryKey(productId);
	    product.setEnable(false);
	    return productMapper.updateByPrimaryKeySelective(product);
	}

	@Override
	public int getProductPrice(long productId) {
		//todo:查价格专门写个SQL 不需要，也不应该专门写个接口  有getProductById接口就好(已修改)
		return this.getProductById(productId).getPrice();
	}

    @Override
    public Product getProductById(Long id) {
        return productMapper.selectByPrimaryKey(id);
    }
}
