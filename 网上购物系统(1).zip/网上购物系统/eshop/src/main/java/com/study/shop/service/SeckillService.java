package com.study.shop.service;

import java.util.List;

import com.study.shop.domain.AddressInfo;
import com.study.shop.domain.SeckillInfo;

public interface SeckillService {

    /**
     * 添加秒杀商品(返回添加后的id)
     * 
     * @param seckill
     * @return
     */
    Long insert(SeckillInfo seckill);

    /**
     * 修改秒杀商品
     * 
     * @param seckill
     */
    void update(SeckillInfo seckill);

    /**
     * 通过id返回秒杀信息
     * 
     * @param id
     * @return
     */
    SeckillInfo getSeckillInfoById(Long id);

    /**
     * 返回所有的秒杀信息(已结束的不算)
     * 
     * @return
     */
    List<SeckillInfo> getSeckillInfoList();

    /**
     * 添加秒杀订单
     * 先创建一个订单然后添加到数据库中，得到订单id来创建订单中的商品并添加到数据库中(秒杀商品一次只能一件)
     * 
     * @param seckillInfo
     * @param addressInfo
     */
    void insertSeckillOrder(SeckillInfo seckillInfo, AddressInfo addressInfo);

    /**
     * 当秒杀时通过id搜索秒杀商品信息来查看是否还有余量,
     * 如果有则通过数据的for update 锁定 id = 参数id的数据，然后更新数据
     * 
     * @param id
     * @return
     */
    boolean updateSeckillInfoWhenSeckill(Long id);
}
