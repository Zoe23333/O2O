项目说明:
   框架采用 spring + mybatis, 数据库连接池使用阿里druid, 日志使用slf4j + log4j
   druid连接池说明参考: https://www.cnblogs.com/niejunlei/p/5977895.html
   mybatis框架配置参考 https://www.cnblogs.com/ClassNotFoundException/p/6425558.html
   mybatis层代码使用mybatis-generator插件自动生成, 使用方法请参考 https://blog.csdn.net/liyonghong3333/article/details/79590588

   
项目结构:
src
   common  公共文件，常量定义等
   domain  实体类
   mapper  mybatis 映射类及映射文件
   mvc	   控制器类
   service 服务类
   util	   工具类
   App	   应用入口
      
resources
   applicationContext.xml  spring配置文件
   generator.properties    mybatis-generator 数据源配置文件(jdbc.driverLocation 需要手动更改!)
   generatorConfig.xml	   mybatis-generator 配置文件
   log4j.properties		   log4j默认配置文件
   mybatis-config.xml	   mybatis配置文件
   
sql
  shop.sql 				   数据库脚本(管理员账号为admin 密码111)
   
build.dev.properties       环境变量配置文件